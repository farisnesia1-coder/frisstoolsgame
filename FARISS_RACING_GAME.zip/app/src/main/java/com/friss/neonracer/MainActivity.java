package com.friss.neonracer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * FARISS RACING GAME - offline school-project prototype.
 * Accounts, top-ups and admin actions are local to this app installation.
 * They are intentionally NOT represented as secure online services.
 */
public class MainActivity extends Activity {
    static { System.loadLibrary("neonracer"); }

    private static final String ADMIN_PIN = "246810"; // Demo-only gate, not production security.
    private static final String TIKTOK_URL = "https://www.tiktok.com/@frissanjaymabar";
    private static final String INSTAGRAM_URL = "https://www.instagram.com/frisswho?vrfl=M3FqeTRqbDd4dHF4";
    private static final String TELEGRAM_URL = "https://t.me/farisisheree";

    private FrameLayout root;
    private GameView game;
    private TextView hud;
    private Button pauseButton;
    private LinearLayout gameControls;
    private View overlay;

    private SharedPreferences globalPrefs, accountsPrefs, prefs;
    private Bitmap[] playerSprites = new Bitmap[4];
    private Bitmap trafficSprite, rivalSprite, policeSprite, truckSprite, coinSprite;

    private boolean inGame = false, gameOverHandled = false, pauseDialogOpen = false;
    private int carStyle, speedLevel, nitroLevel, handlingLevel;
    private boolean effectsOn, leftHanded, musicOn, soundOn;
    private String currentUserId = "", currentUsername = "";

    private MediaPlayer backgroundMusic;
    private int currentTrackRes = 0;
    private SoundPool soundPool;
    private int clickSfx, nitroSfx, coinSfx, crashSfx, engineSfx;
    private int engineStream = 0;
    private boolean nitroSfxPlaying = false;
    private int lastSoundCoinCount = 0;

    private EditText adminIdInput;
    private TextView adminTargetSummary;
    private final int screenBg = Color.rgb(5, 10, 24);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        globalPrefs = getSharedPreferences("fariss_global", MODE_PRIVATE);
        accountsPrefs = getSharedPreferences("fariss_accounts", MODE_PRIVATE);
        prefs = globalPrefs;
        loadSettings();
        loadSprites();
        initSoundPool();
        immersive();

        root = new FrameLayout(this);
        game = new GameView();
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(13);
        hud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hud.setPadding(dp(14), dp(10), dp(64), dp(10));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(hud, hp);
        hud.setVisibility(View.GONE);

        pauseButton = new Button(this);
        pauseButton.setText("Ⅱ");
        pauseButton.setTextSize(16);
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setAllCaps(false);
        pauseButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(0, 113, 170)));
        pauseButton.setOnClickListener(v -> { playClick(); showPauseDialog(); });
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(48), Gravity.TOP | Gravity.RIGHT);
        pp.setMargins(0, dp(3), dp(6), 0);
        root.addView(pauseButton, pp);
        pauseButton.setVisibility(View.GONE);

        gameControls = createGameControls();
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM);
        cp.setMargins(dp(8), 0, dp(8), dp(8));
        root.addView(gameControls, cp);
        gameControls.setVisibility(View.GONE);

        setContentView(root);
        applyNativeOptions();

        String rememberedId = globalPrefs.getString("active_user_id", "");
        JSONObject remembered = findPlayerById(rememberedId);
        if (remembered != null && !remembered.optBoolean("banned", false)) {
            activateUser(remembered, false);
            showMenu();
        } else {
            globalPrefs.edit().remove("active_user_id").apply();
            currentUserId = "";
            currentUsername = "";
            prefs = globalPrefs;
            showAuthScreen();
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void loadSettings() {
        carStyle = prefs.getInt("car_style", 0);
        speedLevel = prefs.getInt("speed_level", 0);
        nitroLevel = prefs.getInt("nitro_level", 0);
        handlingLevel = prefs.getInt("handling_level", 0);
        effectsOn = prefs.getBoolean("effects_on", true);
        musicOn = prefs.getBoolean("music_on", true);
        soundOn = prefs.getBoolean("sound_on", true);
        leftHanded = prefs.getBoolean("left_handed", false);
    }

    private void loadSprites() {
        playerSprites[0] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player);
        playerSprites[1] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_red);
        playerSprites[2] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_purple);
        playerSprites[3] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_white);
        trafficSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_traffic);
        rivalSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_rival);
        policeSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_police);
        truckSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_truck);
        coinSprite = BitmapFactory.decodeResource(getResources(), R.drawable.coin_gold);
    }

    private Bitmap currentPlayerSprite() { return playerSprites[Math.max(0, Math.min(3, carStyle))]; }
    private String carName(int id) {
        switch (id % 4) {
            case 1: return "VOLT RS";
            case 2: return "PHANTOM X";
            case 3: return "POLAR GT";
            default: return "NEXUS GT";
        }
    }

    private void initSoundPool() {
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
        clickSfx = soundPool.load(this, R.raw.sfx_click, 1);
        nitroSfx = soundPool.load(this, R.raw.sfx_nitro, 1);
        coinSfx = soundPool.load(this, R.raw.sfx_coin, 1);
        crashSfx = soundPool.load(this, R.raw.sfx_crash, 1);
        engineSfx = soundPool.load(this, R.raw.sfx_engine, 1);
    }
    private void playSfx(int id, float volume) {
        if (soundOn && soundPool != null && id != 0) {
            try { soundPool.play(id, volume, volume, 1, 0, 1f); } catch (Exception ignored) { }
        }
    }
    private void playClick() { playSfx(clickSfx, .65f); }
    private void startEngineSound() {
        if (!soundOn || soundPool == null || engineSfx == 0 || engineStream != 0) return;
        engineStream = soundPool.play(engineSfx, .17f, .17f, 1, -1, 1f);
    }
    private void stopEngineSound() {
        if (soundPool != null && engineStream != 0) {
            try { soundPool.stop(engineStream); } catch (Exception ignored) { }
        }
        engineStream = 0;
    }
    private void stopNitroSound() {
        if (soundPool != null && nitroSfxPlaying) {
            // Nitro is intentionally a one-shot accent rather than an infinite loop.
            nitroSfxPlaying = false;
        }
        nativeNitro(false);
    }

    private void playTrack(int resourceId) {
        if (currentTrackRes == resourceId && backgroundMusic != null) {
            applyMusicSetting();
            return;
        }
        if (backgroundMusic != null) {
            try { backgroundMusic.stop(); } catch (Exception ignored) { }
            backgroundMusic.release();
            backgroundMusic = null;
        }
        currentTrackRes = resourceId;
        try {
            backgroundMusic = MediaPlayer.create(this, resourceId);
            if (backgroundMusic != null) {
                backgroundMusic.setLooping(true);
                backgroundMusic.setVolume(.42f, .42f);
                if (musicOn) backgroundMusic.start();
            }
        } catch (Exception ignored) { backgroundMusic = null; }
    }
    private void applyMusicSetting() {
        if (backgroundMusic == null && currentTrackRes != 0) playTrack(currentTrackRes);
        if (backgroundMusic == null) return;
        try {
            if (musicOn && !backgroundMusic.isPlaying()) backgroundMusic.start();
            else if (!musicOn && backgroundMusic.isPlaying()) backgroundMusic.pause();
        } catch (Exception ignored) { }
    }

    private void applyNativeOptions() {
        nativeSetUpgrades(speedLevel, nitroLevel, handlingLevel);
        nativeSetOptions(effectsOn, leftHanded);
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        t.setPadding(dp(8), dp(5), dp(8), dp(5));
        return t;
    }
    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(140, 170, 200));
        e.setHint(hint);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(0, 190, 240)));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
    private Button button(String value, Runnable action, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinHeight(dp(46));
        b.setBackgroundTintList(ColorStateList.valueOf(primary ? Color.rgb(0, 145, 210) : Color.rgb(20, 45, 75)));
        b.setOnClickListener(v -> { playClick(); action.run(); });
        return b;
    }
    private LinearLayout makePanel(String titleText) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(18));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setBackgroundColor(screenBg);
        if (titleText != null && !titleText.isEmpty()) {
            TextView title = text(titleText, 25, Color.rgb(40, 220, 255));
            LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
            titleP.setMargins(0, 0, 0, dp(10));
            panel.addView(title, titleP);
        }
        return panel;
    }
    private void showOverlay(View v) {
        if (overlay != null) root.removeView(overlay);
        overlay = v;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        hud.setVisibility(View.GONE);
        pauseButton.setVisibility(View.GONE);
        gameControls.setVisibility(View.GONE);
        game.invalidate();
    }
    private void removeOverlay() {
        if (overlay != null) { root.removeView(overlay); overlay = null; }
    }
    private void addAction(LinearLayout panel, String label, Runnable action, boolean primary) {
        Button b = button(label, action, primary);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(3), 0, dp(3));
        panel.addView(b, p);
    }
    private void addInput(LinearLayout panel, EditText e) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        panel.addView(e, p);
    }

    // -------------------- Offline account prototype --------------------
    private JSONArray getPlayers() {
        try { return new JSONArray(accountsPrefs.getString("players", "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }
    private void savePlayers(JSONArray players) { accountsPrefs.edit().putString("players", players.toString()).apply(); }
    private JSONObject findPlayerById(String id) {
        if (id == null || id.trim().isEmpty()) return null;
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && p.optString("id").equalsIgnoreCase(id.trim())) return p;
        }
        return null;
    }
    private JSONObject findPlayerByNameOrId(String value) {
        if (value == null) return null;
        String v = value.trim();
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && (p.optString("id").equalsIgnoreCase(v) || p.optString("username").equalsIgnoreCase(v))) return p;
        }
        return null;
    }
    private String passwordHash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((salt + ":" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    private void activateUser(JSONObject player, boolean persistSession) {
        currentUserId = player.optString("id", "");
        currentUsername = player.optString("username", "PLAYER");
        if (persistSession) globalPrefs.edit().putString("active_user_id", currentUserId).apply();
        prefs = getSharedPreferences("player_" + currentUserId, MODE_PRIVATE);
        loadSettings();
        applyNativeOptions();
    }
    private void showAuthScreen() {
        inGame = false;
        stopEngineSound();
        playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("PLAYER LOGIN");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo, new LinearLayout.LayoutParams(-1, dp(170)));
        body.addView(text("LOGIN OR CREATE YOUR RACER ID", 12, Color.LTGRAY));
        EditText username = input("Username or player ID", false);
        EditText password = input("Password", true);
        addInput(body, username); addInput(body, password);
        addAction(body, "LOGIN", () -> doLogin(username.getText().toString(), password.getText().toString()), true);
        addAction(body, "CREATE NEW PLAYER", this::showRegisterScreen, false);
        body.addView(text("Offline prototype • IDs and wallets stay on this device", 10, Color.GRAY));
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void showRegisterScreen() {
        LinearLayout panel = makePanel("CREATE PLAYER");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(text("Pick a username. A unique Player ID is generated for you.", 12, Color.LTGRAY));
        EditText username = input("Username (3-16 letters/numbers/._)", false);
        EditText password = input("Password (minimum 6 characters)", true);
        EditText confirm = input("Confirm password", true);
        addInput(body, username); addInput(body, password); addInput(body, confirm);
        addAction(body, "CREATE ACCOUNT", () -> {
            String name = username.getText().toString().trim();
            String pass = password.getText().toString();
            if (!name.matches("[A-Za-z0-9_.]{3,16}")) { alert("Invalid username", "Use 3-16 letters, numbers, underscore or dot."); return; }
            if (pass.length() < 6) { alert("Password too short", "Use at least 6 characters."); return; }
            if (!pass.equals(confirm.getText().toString())) { alert("Password mismatch", "The passwords do not match."); return; }
            if (findPlayerByNameOrId(name) != null) { alert("Username unavailable", "Choose another username."); return; }
            String id = "FRS-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase(Locale.US);
            String salt = UUID.randomUUID().toString();
            JSONObject player = new JSONObject();
            try {
                player.put("id", id); player.put("username", name); player.put("salt", salt);
                player.put("passwordHash", passwordHash(pass, salt)); player.put("banned", false);
                player.put("createdAt", System.currentTimeMillis());
                JSONArray arr = getPlayers(); arr.put(player); savePlayers(arr);
            } catch (JSONException ex) { alert("Account error", "Could not save the account on this device."); return; }
            activateUser(player, true);
            alert("Account created", "Username: " + name + "\nYour Player ID: " + id + "\nSave this ID for reference.");
            showMenu();
        }, true);
        addAction(body, "← BACK TO LOGIN", this::showAuthScreen, false);
        sc.addView(body); panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void doLogin(String usernameOrId, String password) {
        JSONObject player = findPlayerByNameOrId(usernameOrId);
        if (player == null) { alert("Player not found", "Create an account first, or check the username / ID."); return; }
        if (player.optBoolean("banned", false)) { alert("Account banned", "This local player is banned on this device. Contact the local demo administrator."); return; }
        String salt = player.optString("salt", "");
        if (!passwordHash(password, salt).equals(player.optString("passwordHash", ""))) {
            alert("Login failed", "The password is incorrect."); return;
        }
        activateUser(player, true);
        showMenu();
    }
    private void logout() {
        inGame = false; nativePause(true); stopEngineSound(); stopNitroSound();
        currentUserId = ""; currentUsername = "";
        globalPrefs.edit().remove("active_user_id").apply();
        prefs = globalPrefs;
        showAuthScreen();
    }

    // -------------------- Screens --------------------
    private void showMenu() {
        inGame = false;
        pauseDialogOpen = false;
        nativeReset(); nativePause(true); stopEngineSound(); stopNitroSound();
        loadSettings(); applyNativeOptions(); playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("");
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.logo_neon_racer); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo, new LinearLayout.LayoutParams(-1, dp(230)));
        body.addView(text("ANDROID ARCADE RACING", 12, Color.WHITE));
        body.addView(text("DODGE • BOOST • SURVIVE", 11, Color.rgb(135, 190, 220)));
        body.addView(text("PLAYER  " + currentUsername, 15, Color.WHITE));
        body.addView(text("ID  " + currentUserId, 11, Color.rgb(80, 220, 255)));
        body.addView(text("BEST  " + prefs.getInt("best_score", 0) + "   •   WALLET  " + prefs.getInt("bank_coins", 0), 15, Color.rgb(255, 208, 65)));
        addAction(body, "▶  START RACE", this::startGame, true);
        addAction(body, "GARAGE  •  " + carName(carStyle), this::showGarage, false);
        addAction(body, "UPGRADE SHOP", this::showUpgrades, false);
        addAction(body, "COIN TOP-UP VIA TELEGRAM", this::showTopUp, false);
        addAction(body, "LOCAL LEADERBOARD", this::showLeaderboard, false);
        addAction(body, "SETTINGS & AUDIO", this::showSettings, false);
        addAction(body, "DEVELOPER • FARIS", this::showDeveloper, false);
        addAction(body, "ADMIN DASHBOARD", this::askAdminPin, false);
        addAction(body, "LOG OUT", this::logout, false);
        body.addView(text("AI TRAFFIC • RIVALS • POLICE PURSUIT", 10, Color.GRAY));
        scroll.addView(body); panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); showOverlay(panel);
    }

    private LinearLayout createGameControls() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundColor(Color.TRANSPARENT);
        Button left = controlButton("◀ LEFT", 0);
        Button nos = controlButton("⚡ NOS", 1);
        Button right = controlButton("RIGHT ▶", 2);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(58), 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(left, p); row.addView(nos, p); row.addView(right, p);
        return row;
    }
    private Button controlButton(String label, int type) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setAllCaps(false);
        int color = type == 1 ? Color.rgb(0, 170, 220) : Color.rgb(19, 49, 82);
        b.setBackgroundTintList(ColorStateList.valueOf(color)); b.setMinHeight(dp(52));
        b.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                if (type == 0) { nativeSteer(-1); playClick(); }
                else if (type == 2) { nativeSteer(1); playClick(); }
                else { nativeNitro(true); playSfx(nitroSfx, .95f); nitroSfxPlaying = true; }
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                if (type == 1) stopNitroSound();
                return true;
            }
            return true;
        });
        return b;
    }
    private void startGame() {
        removeOverlay(); inGame = true; gameOverHandled = false; pauseDialogOpen = false;
        loadSettings(); applyNativeOptions(); nativeReset(); nativePause(false);
        lastSoundCoinCount = 0;
        hud.setVisibility(View.VISIBLE); pauseButton.setVisibility(View.VISIBLE); gameControls.setVisibility(View.VISIBLE);
        playTrack(R.raw.racing_music); startEngineSound(); game.invalidate();
    }
    private void showPauseDialog() {
        if (!inGame || pauseDialogOpen) return;
        pauseDialogOpen = true; nativePause(true); stopNitroSound(); stopEngineSound();
        if (backgroundMusic != null && backgroundMusic.isPlaying()) backgroundMusic.pause();
        new AlertDialog.Builder(this).setTitle("RACE PAUSED").setMessage("Take a break, racer.").setCancelable(false)
            .setPositiveButton("RESUME", (d,w) -> { pauseDialogOpen = false; if (inGame) { nativePause(false); applyMusicSetting(); startEngineSound(); } game.invalidate(); })
            .setNeutralButton("RESTART", (d,w) -> { pauseDialogOpen = false; startGame(); })
            .setNegativeButton("MAIN MENU", (d,w) -> { pauseDialogOpen = false; showMenu(); }).show();
    }
    private void finishGameIfNeeded() {
        if (!inGame || gameOverHandled || !nativeGameOver()) return;
        gameOverHandled = true; inGame = false; playSfx(crashSfx, 1f); stopEngineSound(); stopNitroSound(); playTrack(R.raw.dashboard_music);
        int score = nativeScore(), earned = nativeCoins();
        int best = Math.max(score, prefs.getInt("best_score", 0));
        int bank = prefs.getInt("bank_coins", 0) + earned;
        prefs.edit().putInt("best_score", best).putInt("bank_coins", bank).putInt("last_score", score).apply();
        saveLocalScore(score);
        hud.setVisibility(View.GONE); pauseButton.setVisibility(View.GONE); gameControls.setVisibility(View.GONE);
        new AlertDialog.Builder(this).setTitle("RACE OVER")
            .setMessage("Player: " + currentUsername + "\nID: " + currentUserId + "\nScore: " + score + "\nBest: " + best + "\nCoins earned: " + earned + "\nWallet: " + bank)
            .setCancelable(false).setPositiveButton("RACE AGAIN", (d,w) -> startGame())
            .setNeutralButton("GARAGE", (d,w) -> showGarage()).setNegativeButton("MAIN MENU", (d,w) -> showMenu()).show();
    }
    private void saveLocalScore(int score) {
        String raw = prefs.getString("local_scores", ""); List<Integer> scores = new ArrayList<>();
        if (!raw.isEmpty()) for (String s : raw.split(",")) { try { scores.add(Integer.parseInt(s)); } catch (NumberFormatException ignored) { } }
        scores.add(score); Collections.sort(scores, Collections.reverseOrder()); StringBuilder out = new StringBuilder();
        for (int i=0; i<Math.min(10,scores.size()); i++) { if (i>0) out.append(','); out.append(scores.get(i)); }
        prefs.edit().putString("local_scores", out.toString()).apply();
    }
    private void showGarage() {
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("GARAGE"); panel.addView(text("SELECT YOUR RIDE", 12, Color.WHITE));
        ImageView carPreview = new ImageView(this); carPreview.setImageBitmap(currentPlayerSprite()); carPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        panel.addView(carPreview, new LinearLayout.LayoutParams(dp(120), dp(165)));
        panel.addView(text(carName(carStyle), 22, Color.rgb(80,220,255)));
        panel.addView(text("STYLE " + (carStyle+1) + "/4  •  SPEED " + (6+speedLevel) + "/10", 11, Color.LTGRAY));
        addAction(panel, "NEXT CAR →", () -> { carStyle=(carStyle+1)%4; prefs.edit().putInt("car_style",carStyle).apply(); showGarage(); }, true);
        addAction(panel, "UPGRADE SHOP", this::showUpgrades, false); addAction(panel, "← BACK TO MENU", this::showMenu, false); showOverlay(panel);
    }
    private void showUpgrades() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("UPGRADE SHOP");
        panel.addView(text("WALLET  " + prefs.getInt("bank_coins",0) + " COINS", 14, Color.rgb(255,205,55)));
        panel.addView(text("SPEED • LEVEL " + speedLevel + "/5", 13, Color.WHITE));
        addAction(panel, speedLevel>=5?"SPEED MAX LEVEL":"UPGRADE SPEED • "+upgradeCost(speedLevel), ()->purchaseUpgrade("speed"), true);
        panel.addView(text("NITRO • LEVEL " + nitroLevel + "/5", 13, Color.WHITE));
        addAction(panel, nitroLevel>=5?"NITRO MAX LEVEL":"UPGRADE NITRO • "+upgradeCost(nitroLevel), ()->purchaseUpgrade("nitro"), true);
        panel.addView(text("HANDLING • LEVEL " + handlingLevel + "/5", 13, Color.WHITE));
        addAction(panel, handlingLevel>=5?"HANDLING MAX LEVEL":"UPGRADE HANDLING • "+upgradeCost(handlingLevel), ()->purchaseUpgrade("handling"), true);
        addAction(panel, "COIN TOP-UP VIA TELEGRAM", this::showTopUp, false); addAction(panel, "← BACK TO MENU", this::showMenu, false); showOverlay(panel);
    }
    private int upgradeCost(int level) { return 250 + level*350; }
    private void purchaseUpgrade(String which) {
        int level = which.equals("speed")?speedLevel:which.equals("nitro")?nitroLevel:handlingLevel;
        if(level>=5) return; int cost=upgradeCost(level), bank=prefs.getInt("bank_coins",0);
        if(bank<cost) { alert("NOT ENOUGH COINS", "Need " + cost + " coins. Earn coins from races or order a top-up via Telegram."); return; }
        bank-=cost; if(which.equals("speed")) speedLevel++; else if(which.equals("nitro")) nitroLevel++; else handlingLevel++;
        prefs.edit().putInt("bank_coins",bank).putInt("speed_level",speedLevel).putInt("nitro_level",nitroLevel).putInt("handling_level",handlingLevel).apply();
        applyNativeOptions(); showUpgrades();
    }
    private void showLeaderboard() {
        inGame=false; nativePause(true); LinearLayout panel=makePanel("LOCAL LEADERBOARD");
        panel.addView(text("TOP SCORES • THIS DEVICE ACCOUNT", 11, Color.LTGRAY)); String raw=prefs.getString("local_scores","");
        if(raw.isEmpty()) panel.addView(text("No races recorded yet. Start your first race!",13,Color.WHITE));
        else { String[] scores=raw.split(","); for(int i=0;i<scores.length;i++) panel.addView(text((i+1)+".  "+currentUsername+"   "+scores[i],14,i==0?Color.rgb(255,210,65):Color.WHITE)); }
        panel.addView(text("BEST  "+prefs.getInt("best_score",0)+"  •  WALLET  "+prefs.getInt("bank_coins",0),12,Color.rgb(75,220,255)));
        addAction(panel,"← BACK TO MENU",this::showMenu,true); showOverlay(panel);
    }

    private void showTopUp() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("COIN TOP-UP");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(text("MANUAL TOP-UP • TELEGRAM CHAT",12,Color.rgb(75,220,255)));
        body.addView(text("PLAYER  "+currentUsername,13,Color.WHITE));
        body.addView(text("PLAYER ID  "+currentUserId,12,Color.rgb(150,210,240)));
        body.addView(text("CURRENT WALLET  "+prefs.getInt("bank_coins",0)+" COINS",15,Color.rgb(255,205,55)));
        body.addView(text("Pilih paket untuk mengirim pesanan ke chat FRISS. Harga dan cara pembayaran dikonfirmasi admin lewat Telegram.",11,Color.LTGRAY));
        addAction(body,"ORDER VIA TELEGRAM • 500 COINS",()->sendTelegramTopupOrder(500),true);
        addAction(body,"ORDER VIA TELEGRAM • 1,500 COINS",()->sendTelegramTopupOrder(1500),true);
        addAction(body,"ORDER VIA TELEGRAM • 5,000 COINS",()->sendTelegramTopupOrder(5000),true);
        body.addView(text("Koin belum otomatis bertambah setelah membuka chat. Admin harus mengecek pembayaran dan mengkreditkan koin.",10,Color.GRAY));
        addAction(body,"← BACK TO MENU",this::showMenu,false);
        sc.addView(body); panel.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }

    private void sendTelegramTopupOrder(int coinAmount) {
        String message = "Halo FRISS! Saya mau top up FARISS RACING GAME.\n"
            + "Username: " + currentUsername + "\n"
            + "Player ID: " + currentUserId + "\n"
            + "Paket: " + String.format(Locale.US, "%,d", coinAmount) + " koin\n"
            + "Status: belum membayar\n"
            + "Mohon konfirmasi harga dan metode pembayaran sebelum saya membayar.";
        openExternal(TELEGRAM_URL + "?text=" + Uri.encode(message));
    }

    // -------------------- Local demo administration --------------------
    private void askAdminPin() {
        EditText pin = input("Admin PIN", true); pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("ADMIN ACCESS • LOCAL DEMO").setMessage("PIN demo: akses ini hanya mengelola data yang tersimpan di perangkat ini.")
            .setView(pin).setNegativeButton("CANCEL", null).setPositiveButton("OPEN", (d,w)->{
                if (ADMIN_PIN.equals(pin.getText().toString())) showAdminDashboard();
                else alert("ACCESS DENIED", "Incorrect demo PIN.");
            }).show();
    }
    private void showAdminDashboard() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("ADMIN DASHBOARD");
        panel.addView(text("LOCAL DEVICE ONLY • NOT SHARED ONLINE",11,Color.rgb(255,205,55)));
        panel.addView(text("Manage registered local Player IDs",11,Color.LTGRAY));
        adminIdInput=input("Enter Player ID (FRS-XXXXXXXX)",false); addInput(panel,adminIdInput);
        adminTargetSummary=text("No player selected",12,Color.WHITE); panel.addView(adminTargetSummary);
        addAction(panel,"LOOKUP PLAYER ID",this::lookupAdminTarget,true);
        addAction(panel,"BAN PLAYER",()->changeBanState(true),false);
        addAction(panel,"UNBAN PLAYER",()->changeBanState(false),false);
        addAction(panel,"ADD CUSTOM COINS TO PLAYER ID",this::askAdminCreditAmount,true);
        addAction(panel,"← BACK TO MENU",this::showMenu,false);
        showOverlay(panel);
    }
    private String adminTypedId() { return adminIdInput==null?"":adminIdInput.getText().toString().trim().toUpperCase(Locale.US); }
    private void lookupAdminTarget() {
        String id=adminTypedId(); JSONObject p=findPlayerById(id);
        if(p==null) { adminTargetSummary.setText("Player ID not found on this device."); return; }
        adminTargetSummary.setText("Username: "+p.optString("username")+"\nID: "+p.optString("id")+"\nStatus: "+(p.optBoolean("banned")?"BANNED":"ACTIVE")+"\nWallet: "+getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE).getInt("bank_coins",0)+" coins");
    }
    private void changeBanState(boolean ban) {
        String id=adminTypedId(); JSONArray players=getPlayers(); boolean found=false; String name="";
        for(int i=0;i<players.length();i++){ JSONObject p=players.optJSONObject(i); if(p!=null&&p.optString("id").equalsIgnoreCase(id)){ try{p.put("banned",ban);name=p.optString("username");found=true;}catch(JSONException ignored){} break; } }
        if(!found){adminTargetSummary.setText("Player ID not found. Look up an ID first.");return;}
        savePlayers(players); lookupAdminTarget();
        alert("PLAYER UPDATED",name+" has been "+(ban?"banned":"unbanned")+" in this device's local demo database.");
    }
    private void askAdminCreditAmount() {
        String id=adminTypedId();
        JSONObject p=findPlayerById(id);
        if(p==null){adminTargetSummary.setText("Player ID not found on this device. This dashboard cannot manage accounts on other devices.");return;}
        EditText amountInput=input("Coins to add (e.g. 1000)",false);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("CREDIT PLAYER WALLET")
            .setMessage("Only credit coins after confirming the payment was received. This change applies only on this device.")
            .setView(amountInput).setNegativeButton("CANCEL",null).setPositiveButton("ADD COINS",(d,w)->{
                String raw=amountInput.getText().toString().trim();
                int amount;
                try { amount=Integer.parseInt(raw); } catch(Exception ex) { alert("INVALID AMOUNT","Enter a whole number greater than zero."); return; }
                if(amount<=0 || amount>10000000){alert("INVALID AMOUNT","Enter an amount from 1 to 10,000,000 coins.");return;}
                creditPlayerLocally(p,amount);
            }).show();
    }
    private void creditPlayerLocally(JSONObject p, int amount) {
        SharedPreferences target=getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE);
        int oldCoins=target.getInt("bank_coins",0);
        if(Integer.MAX_VALUE-oldCoins<amount){alert("WALLET LIMIT","This amount exceeds the wallet limit.");return;}
        target.edit().putInt("bank_coins",oldCoins+amount).putInt("admin_credit_count",target.getInt("admin_credit_count",0)+1)
            .putString("last_admin_credit",System.currentTimeMillis()+":"+amount).apply();
        lookupAdminTarget();
        alert("LOCAL CREDIT ADDED","+"+String.format(Locale.US,"%,d",amount)+" coins granted to "+p.optString("username")+" ("+p.optString("id")+").\n\nReminder: this prototype stores player data on this device only.");
    }

    private void showDeveloper() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel(""); panel.setBackgroundColor(Color.BLACK);
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(12),dp(18),dp(12),dp(18));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_neon_racer); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout nameRow=new LinearLayout(this); nameRow.setGravity(Gravity.CENTER); nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.addView(text("FARIS",34,Color.WHITE)); nameRow.addView(text(" ✓ ",22,Color.rgb(70,145,255))); body.addView(nameRow);
        body.addView(text("NEON RACER • DEVELOPER",12,Color.LTGRAY));
        LinearLayout.LayoutParams contactP=new LinearLayout.LayoutParams(-1,-2); contactP.setMargins(0,dp(20),0,dp(6)); body.addView(text("SOCIALS:",14,Color.WHITE),contactP);
        addAction(body,"♪  TIKTOK  •  @frissanjaymabar",()->openExternal(TIKTOK_URL),false);
        addAction(body,"◎  INSTAGRAM  •  @frisswho",()->openExternal(INSTAGRAM_URL),false);
        addAction(body,"➤  TELEGRAM  •  @farisisheree",()->openExternal(TELEGRAM_URL),false);
        addAction(body,"← BACK TO MENU",this::showMenu,true);
        scroll.addView(body); panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }
    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { alert("Cannot open link",url); }
    }
    private void showSettings() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("SETTINGS & AUDIO");
        panel.addView(text("BACKGROUND MUSIC",13,Color.WHITE));
        addAction(panel,"MUSIC: "+(musicOn?"ON":"OFF"),()->{musicOn=!musicOn;prefs.edit().putBoolean("music_on",musicOn).apply();applyMusicSetting();showSettings();},true);
        panel.addView(text("SOUND EFFECTS • CLICK / NOS / COIN / CRASH / ENGINE",10,Color.LTGRAY));
        addAction(panel,"SOUND FX: "+(soundOn?"ON":"OFF"),()->{soundOn=!soundOn;prefs.edit().putBoolean("sound_on",soundOn).apply();if(!soundOn)stopEngineSound();else if(inGame)startEngineSound();showSettings();},true);
        panel.addView(text("VISUAL EFFECTS",13,Color.WHITE));
        addAction(panel,"EFFECTS: "+(effectsOn?"ON":"OFF"),()->{effectsOn=!effectsOn;prefs.edit().putBoolean("effects_on",effectsOn).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();},true);
        panel.addView(text("CONTROL LAYOUT",13,Color.WHITE));
        addAction(panel,"LEFT-HANDED: "+(leftHanded?"ON":"OFF"),()->{leftHanded=!leftHanded;prefs.edit().putBoolean("left_handed",leftHanded).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();},true);
        panel.addView(text("Original procedural electronic soundtrack • offline",10,Color.GRAY)); addAction(panel,"← BACK TO MENU",this::showMenu,false); showOverlay(panel);
    }

    private void alert(String title,String message) { new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",null).show(); }

    @Override protected void onPause() {
        super.onPause(); if(game!=null&&inGame)nativePause(true); stopEngineSound(); stopNitroSound();
        if(backgroundMusic!=null&&backgroundMusic.isPlaying())backgroundMusic.pause();
    }
    @Override protected void onResume() {
        super.onResume(); immersive(); if(game!=null&&inGame&&!pauseDialogOpen){nativePause(false);startEngineSound();} applyMusicSetting();
    }
    @Override protected void onDestroy() {
        if(backgroundMusic!=null){try{backgroundMusic.stop();}catch(Exception ignored){}backgroundMusic.release();backgroundMusic=null;}
        if(soundPool!=null){soundPool.release();soundPool=null;} super.onDestroy();
    }

    private class GameView extends View {
        GameView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_HARDWARE,null);}
        @Override protected void onDraw(android.graphics.Canvas canvas){
            super.onDraw(canvas);
            if(inGame){
                nativeRender(canvas,getWidth(),getHeight(),currentPlayerSprite(),trafficSprite,rivalSprite,policeSprite,truckSprite,coinSprite);
                int coins=nativeCoins(); if(coins>lastSoundCoinCount){playSfx(coinSfx,.85f);lastSoundCoinCount=coins;}
                hud.setText(currentUsername+"  •  SCORE "+nativeScore()+"  •  COINS "+coins+"  •  BEST "+prefs.getInt("best_score",0));
                finishGameIfNeeded(); if(inGame)postInvalidateDelayed(16);
            } else canvas.drawColor(screenBg);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(!inGame)return true;
            float x=e.getX()/Math.max(1f,getWidth()),y=e.getY()/Math.max(1f,getHeight());
            if(e.getAction()==MotionEvent.ACTION_DOWN){if(y<.14f&&x>.72f){showPauseDialog();return true;}nativeTouch(x,y);return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){if(x>.43f&&x<.57f&&y>.38f)nativeTouch(x,y);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){nativeTouch(-1f,-1f);return true;}
            return true;
        }
    }

    private native void nativeRender(android.graphics.Canvas canvas,int width,int height,Bitmap player,Bitmap traffic,Bitmap rival,Bitmap police,Bitmap truck,Bitmap coin);
    private native void nativeTouch(float x,float y);
    private native void nativeSteer(int direction);
    private native void nativeNitro(boolean down);
    private native int nativeScore();
    private native int nativeCoins();
    private native boolean nativeGameOver();
    private native void nativePause(boolean paused);
    private native void nativeReset();
    private native void nativeSetUpgrades(int speed,int nitro,int handling);
    private native void nativeSetOptions(boolean effects,boolean leftHanded);
}
