# FARISS RACING GAME — FRISS EDITION

An Android arcade-racing school-project prototype using a Java Android UI and C++17 native gameplay through JNI. This package contains the Android project, art assets, audio assets, and a GitHub Actions workflow in one ZIP.

## Features included in source

### Game and controls
- Portrait Android arcade racing game with neon road, scrolling city silhouettes and lane markings.
- On-screen LEFT and RIGHT buttons, plus a hold-to-use NOS button.
- Player car sprites, traffic cars, rival cars, police pursuit NPC, truck obstacles and coin pickups.
- Nitro energy bar and boost streak visuals; collisions trigger Game Over.
- Pause, restart and return-to-menu flow.

### Audio
- Original procedurally generated offline dashboard soundtrack (`dashboard_music.wav`).
- Separate original in-game racing soundtrack (`racing_music.wav`).
- Sound effects for UI button taps, NOS, coin pickups, crashes, and a low-volume looping engine sound.
- Music and sound effects can be toggled in Settings. App pauses audio when put in the background.

### Player profiles
- Local registration with unique generated Player ID (`FRS-XXXXXXXX`), username and password.
- Login using username or Player ID.
- Password hashes are stored rather than plain-text passwords.
- Per-profile best score, wallet coins, car style, upgrades, settings and local leaderboard.

### Wallet, top-up and admin
- In-game coin wallet, garage, upgrades, leaderboard and a **demo-only coin top-up screen**.
- Local demo admin dashboard can look up a registered Player ID, ban/unban that local profile, and grant 1,000 demo coins.
- Demo admin PIN: `246810`.

**Important limitation:** profiles, bans, admin actions, wallet and top-ups are stored only on the current device. The demo top-up does not charge money and is not a real payment system. The admin PIN is deliberately only a demonstration gate, not production security. A real game with accounts shared across devices, server-side bans and real top-ups requires a secure backend/database, server authorization and a legitimate payment provider; those services are not included or claimed to be active in this package.

### Developer menu
- TikTok: https://www.tiktok.com/@frissanjaymabar
- Instagram: https://www.instagram.com/frisswho?vrfl=M3FqeTRqbDd4dHF4
- Telegram: https://t.me/farisisheree

## How to use this ZIP with the existing repository

If the repository currently stores this source archive as `FARISS_RACING_GAME.zip` and has an **Auto Unzip Fix** workflow:
1. Replace the repository file `FARISS_RACING_GAME.zip` with this package (keep the filename exactly the same).
2. Keep the repository's `.github/workflows/android.yml` auto-unzip workflow as-is.
3. Commit the ZIP replacement and run Actions. That workflow should extract the package, find `settings.gradle`, and build it.
4. Download the artifact named `FARISS_RACING_GAME` from a successful run; it contains `FARISS_RACING_GAME.apk`.

If uploading the extracted project directly instead, upload all files/folders from this ZIP to the repository root (including the hidden `.github` folder) and use the included direct-build workflow.

## Toolchain
- JDK 17
- Android SDK Platform 35 / Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.9

## Status
The full project and workflow are prepared, but this chat has not run a full Android Gradle/NDK build or installed the APK on a device. Use GitHub Actions logs to verify compilation, then test the resulting APK. This is a local school-project prototype, not a production-ready online game.
