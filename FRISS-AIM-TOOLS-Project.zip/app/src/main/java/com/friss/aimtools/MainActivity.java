package com.friss.aimtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(8,14,30), panel=Color.rgb(17,28,51), blue=Color.rgb(38,133,255), white=Color.rgb(239,245,255), muted=Color.rgb(157,176,207);
    private LinearLayout root;
    private TextView status;
    private SharedPreferences prefs;
    private final Shizuku.OnRequestPermissionResultListener listener=(requestCode, grantResult)->refreshStatus();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        prefs=getSharedPreferences("profiles",MODE_PRIVATE);
        Shizuku.addRequestPermissionResultListener(listener);
        build();
    }
    private GradientDrawable shape(int c,int r){ GradientDrawable d=new GradientDrawable(); d.setColor(c); d.setCornerRadius(r); return d; }
    private TextView txt(String s,int size,int c,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(c); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private void gap(LinearLayout p,int h){ p.addView(new View(this),new LinearLayout.LayoutParams(1,h)); }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(18,16,18,16); c.setBackground(shape(panel,22)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=14; root.addView(c,lp); return c; }
    private Button btn(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setTextColor(-1); b.setAllCaps(false); b.setBackground(shape(blue,14)); b.setOnClickListener(v->r.run()); return b; }

    private void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,24,20,28); root.setBackgroundColor(bg); scroll.addView(root); setContentView(scroll);
        root.addView(txt("FRISS",15,blue,true)); gap(root,5); root.addView(txt("AIM TOOLS",29,white,true)); root.addView(txt("Sensitivity workspace • Android",13,muted,false)); gap(root,22);

        LinearLayout p=card(); p.addView(txt("SENSITIVITY PROFILE",12,blue,true)); gap(p,8);
        p.addView(txt("Simpan catatan sensitivitas X/Y di perangkat. Profil tidak mengubah pengaturan Free Fire otomatis.",13,muted,false)); gap(p,8);
        EditText x=new EditText(this); x.setSingleLine(true); x.setHint("Nilai X (horizontal)"); x.setTextColor(white); x.setHintTextColor(muted); x.setInputType(2); x.setText(""+prefs.getInt("x",90)); p.addView(x);
        EditText y=new EditText(this); y.setSingleLine(true); y.setHint("Nilai Y (vertical)"); y.setTextColor(white); y.setHintTextColor(muted); y.setInputType(2); y.setText(""+prefs.getInt("y",85)); p.addView(y); gap(p,8);
        p.addView(btn("Simpan profil",()->{try{int a=Integer.parseInt(x.getText().toString()),b=Integer.parseInt(y.getText().toString());if(a<0||a>200||b<0||b>200)throw new NumberFormatException();prefs.edit().putInt("x",a).putInt("y",b).apply();Toast.makeText(this,"Profil tersimpan",0).show();}catch(Exception e){Toast.makeText(this,"Masukkan nilai 0–200",0).show();}}));

        LinearLayout d=card(); d.addView(txt("DEVICE INFO",12,blue,true)); gap(d,8); d.addView(txt("Perangkat: "+android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL,14,white,false)); d.addView(txt("Android: "+android.os.Build.VERSION.RELEASE+" (API "+android.os.Build.VERSION.SDK_INT+")",13,muted,false)); gap(d,8);
        d.addView(btn("Cek refresh rate layar",()->{float hz=getWindowManager().getDefaultDisplay().getRefreshRate();new android.app.AlertDialog.Builder(this).setTitle("Refresh rate").setMessage(String.format(java.util.Locale.US,"Layar melaporkan %.1f Hz. Ini bukan jaminan FPS game.",hz)).setPositiveButton("OK",null).show();}));

        LinearLayout sh=card(); sh.addView(txt("SHIZUKU STATUS",12,blue,true)); gap(sh,8); status=txt("",14,white,false); sh.addView(status); gap(sh,8);
        sh.addView(btn("Periksa izin Shizuku",this::refreshStatus)); gap(sh,8);
        sh.addView(btn("Minta izin Shizuku",()->{try{if(Shizuku.pingBinder()){if(Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED)refreshStatus();else Shizuku.requestPermission(1001);}else new android.app.AlertDialog.Builder(this).setTitle("Shizuku belum aktif").setMessage("Buka aplikasi Shizuku dan mulai layanannya terlebih dahulu.").setPositiveButton("OK",null).show();}catch(Throwable e){Toast.makeText(this,"Periksa aplikasi Shizuku",1).show();}})); gap(sh,8);
        sh.addView(txt("Build fix: tidak lagi memanggil Shizuku.newProcess() yang private. Versi ini memeriksa koneksi/izin Shizuku, tanpa menjalankan shell atau mengubah game/sistem otomatis.",12,muted,false));

        LinearLayout tl=card(); tl.addView(txt("TOUCH LAB",12,blue,true)); gap(tl,8); tl.addView(txt("Geser jari di area ini untuk melihat perpindahan sentuhan di dalam aplikasi.",13,muted,false)); gap(tl,10);
        TextView pad=txt("GESER DI SINI",14,white,true); pad.setGravity(Gravity.CENTER); pad.setBackground(shape(Color.rgb(24,43,76),18)); tl.addView(pad,new LinearLayout.LayoutParams(-1,170));
        pad.setOnTouchListener((v,e)->{if(e.getAction()==0){pad.setTag(new float[]{e.getX(),e.getY()});pad.setText("MULAI…");return true;}if(e.getAction()==1){float[] s=(float[])pad.getTag();pad.setText(String.format(java.util.Locale.US,"X: %.0f px • Y: %.0f px",e.getX()-s[0],e.getY()-s[1]));return true;}return true;});
    }
    private void refreshStatus(){if(status==null)return;try{if(Shizuku.pingBinder())status.setText(Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED?"Terhubung • Izin diberikan":"Terhubung • Izin belum diberikan");else status.setText("Belum terhubung • Mulai layanan Shizuku");}catch(Throwable e){status.setText("Status belum tersedia • Periksa aplikasi Shizuku");}}
    @Override protected void onResume(){super.onResume();refreshStatus();}
    @Override protected void onDestroy(){Shizuku.removeRequestPermissionResultListener(listener);super.onDestroy();}
}
