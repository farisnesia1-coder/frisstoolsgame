package com.friss.aimtools;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(7,13,27), panel=Color.rgb(17,29,49), blue=Color.rgb(65,145,255), muted=Color.rgb(165,185,213);
    private SharedPreferences prefs; private TextView status; private static final int REQ=7341;
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("profiles",MODE_PRIVATE);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);home();}
    private GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    private TextView txt(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(18,16,18,22);l.setBackgroundColor(bg);return l;}
    private LinearLayout card(LinearLayout p){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(16,14,16,14);c.setBackground(shape(panel,24));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);p.addView(c,lp);return c;}
    private void btn(LinearLayout p,String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(shape(blue,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);p.addView(b,lp);b.setOnClickListener(v->r.run());}
    private void home(){LinearLayout root=col();ScrollView sc=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(1);sc.addView(body);root.addView(sc);body.addView(txt("FRISS",14,blue,true));body.addView(txt("AIM TOOLS",30,Color.WHITE,true));body.addView(txt("FREE FIRE HELPER • REDMI 12 • ANDROID 15",12,muted,false));
        LinearLayout a=card(body);a.addView(txt("SHIZUKU CONNECTION",13,muted,true));status=txt(statusText(),16,Color.WHITE,true);status.setPadding(0,10,0,10);a.addView(status);btn(a,"Connect / Request permission",this::connect);
        LinearLayout p=card(body);p.addView(txt("X / Y SENSITIVITY PROFILES",15,Color.WHITE,true));p.addView(txt("Simpan nilai untuk dicoba manual di pengaturan Free Fire. Tidak mengubah game otomatis.",13,muted,false));btn(p,"Open profile tuner",this::profiles);
        LinearLayout t=card(body);t.addView(txt("TOUCH LAB",15,Color.WHITE,true));t.addView(txt("Tes swipe horizontal, vertikal, dan diagonal di dalam aplikasi.",13,muted,false));btn(t,"Start touch test",this::touchLab);
        LinearLayout s=card(body);s.addView(txt("SMOOTH SETTINGS",15,Color.WHITE,true));s.addView(txt("Baca refresh-rate settings dan kelola skala animasi sistem yang didukung. Tidak menjamin aim jadi lebih mulus.",13,muted,false));btn(s,"Check refresh rate",this::refresh);btn(s,"Backup & set animations to 0.5x",()->setAnimations());btn(s,"Restore backed-up animations",this::restoreAnimations);
        body.addView(txt("FRISS • FARIS  |  NO ADS • NO ROOT",12,muted,false));setContentView(root);}
    private String statusText(){try{if(!Shizuku.pingBinder())return "Not connected — start Shizuku first";return Shizuku.checkSelfPermission()==0?"Connected • Permission granted":"Connected • Permission needed";}catch(Throwable e){return "Shizuku unavailable";}}
    private void connect(){try{if(!Shizuku.pingBinder()){new AlertDialog.Builder(this).setTitle("Shizuku not running").setMessage("Buka Shizuku, start service, lalu kembali ke FRISS AIM TOOLS.").setPositiveButton("OK",null).show();return;}if(Shizuku.checkSelfPermission()!=0)Shizuku.requestPermission(REQ);else{status.setText(statusText());toast("Shizuku ready");}}catch(Throwable e){toast("Shizuku error: "+e.getClass().getSimpleName());}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ){toast(g.length>0&&g[0]==0?"Permission granted":"Permission denied");if(status!=null)status.setText(statusText());}}
    private EditText edit(String hint,String val,boolean num){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(val);e.setTextColor(Color.WHITE);e.setHintTextColor(muted);e.setPadding(14,8,14,8);e.setBackground(shape(panel,14));if(num)e.setInputType(InputType.TYPE_CLASS_NUMBER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);e.setLayoutParams(lp);return e;}
    private void profiles(){LinearLayout l=col();l.addView(txt("X / Y PROFILE TUNER",24,Color.WHITE,true));l.addView(txt("Profil ini hanya catatan; masukkan angka secara manual di game.",13,muted,false));EditText n=edit("Nama profil",prefs.getString("n","Training"),false),x=edit("Nilai X",prefs.getString("x","100"),true),y=edit("Nilai Y",prefs.getString("y","100"),true);l.addView(n);l.addView(x);l.addView(y);btn(l,"Save profile",()->{prefs.edit().putString("n",n.getText().toString()).putString("x",x.getText().toString()).putString("y",y.getText().toString()).apply();toast("Profile saved");});btn(l,"Back",this::home);setContentView(l);}
    private void touchLab(){LinearLayout l=col();l.addView(txt("TOUCH LAB",24,Color.WHITE,true));l.addView(txt("Geser jari di area ini. Ini mengukur swipe yang diterima aplikasi ini, bukan input Free Fire.",13,muted,false));TouchPad pad=new TouchPad(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,0,1);pp.setMargins(0,12,0,12);l.addView(pad,pp);btn(l,"Back",this::home);setContentView(l);}
    private class TouchPad extends View{Paint p=new Paint(3);float sx,sy,ex,ey;boolean active=false;String result="Swipe to test";TouchPad(Context c){super(c);setBackground(shape(panel,20));}protected void onDraw(Canvas c){super.onDraw(c);p.setColor(blue);p.setStrokeWidth(4);p.setStyle(Paint.Style.STROKE);c.drawRoundRect(8,8,getWidth()-8,getHeight()-8,20,20,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextSize(18);c.drawText(result,24,42,p);if(active){p.setColor(blue);p.setStrokeWidth(5);p.setStyle(Paint.Style.STROKE);c.drawLine(sx,sy,ex,ey,p);p.setStyle(Paint.Style.FILL);c.drawCircle(ex,ey,7,p);}}public boolean onTouchEvent(MotionEvent e){if(e.getAction()==0){sx=ex=e.getX();sy=ey=e.getY();active=true;result="Tracking swipe…";invalidate();return true;}if(e.getAction()==2){ex=e.getX();ey=e.getY();invalidate();return true;}if(e.getAction()==1){ex=e.getX();ey=e.getY();result=String.format(Locale.US,"X: %.0f px • Y: %.0f px",ex-sx,ey-sy);active=false;invalidate();return true;}return true;}}
    private boolean permission(){try{if(!Shizuku.pingBinder()){toast("Start Shizuku first");return false;}if(Shizuku.checkSelfPermission()!=0){Shizuku.requestPermission(REQ);return false;}return true;}catch(Throwable e){toast("Shizuku unavailable");return false;}}
    private interface Done{void result(String s);} private void shell(String cmd,Done done){if(!permission())return;new Thread(()->{StringBuilder o=new StringBuilder();try{Process p=Shizuku.newProcess(new String[]{"sh","-c",cmd},null,null);BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));String line;while((line=r.readLine())!=null)o.append(line).append('\n');BufferedReader er=new BufferedReader(new InputStreamReader(p.getErrorStream()));while((line=er.readLine())!=null)o.append(line).append('\n');p.waitFor();}catch(Throwable e){o.append("Command failed: ").append(e.getClass().getSimpleName()).append(" ").append(e.getMessage());}String out=o.toString().trim();runOnUiThread(()->done.result(out));}).start();}
    private void refresh(){shell("echo peak_refresh_rate=$(settings get system peak_refresh_rate); echo min_refresh_rate=$(settings get system min_refresh_rate); dumpsys display | grep -i 'refresh rate' | head -5",out->new AlertDialog.Builder(this).setTitle("Refresh-rate info").setMessage(out.isEmpty()?"No value returned; vendor may restrict query.":out).setPositiveButton("OK",null).show());}
    private void setAnimations(){String c="mkdir -p /sdcard/Android/data/com.friss.aimtools/files; for k in window_animation_scale transition_animation_scale animator_duration_scale; do settings get global $k > /sdcard/Android/data/com.friss.aimtools/files/$k.bak; done; settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5";shell(c,out->new AlertDialog.Builder(this).setTitle("Animation settings").setMessage("Command attempted. If Android/vendor denies writes, use Developer options manually.\n\n"+out).setPositiveButton("OK",null).show());}
    private void restoreAnimations(){String c="for k in window_animation_scale transition_animation_scale animator_duration_scale; do f=/sdcard/Android/data/com.friss.aimtools/files/$k.bak; if [ -f \"$f\" ]; then v=$(cat \"$f\"); case \"$v\" in ''|null) v=1.0;; esac; settings put global \"$k\" \"$v\"; fi; done";shell(c,out->new AlertDialog.Builder(this).setTitle("Restore attempted").setMessage("If backup files were inaccessible, restore values manually in Developer options.\n\n"+out).setPositiveButton("OK",null).show());}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
