FRISS AIM TOOLS — SOURCE PROJECT
Target: Android 15 / Redmi 12. Java 17. Shizuku API. No ads, no root.

FEATURES
- X/Y sensitivity profiles are local notes only; they do not change Free Fire.
- Touch Lab shows swipe delta within this app only; it cannot measure Free Fire input or diagnose hardware digitizer accuracy.
- Refresh-rate query checks Android settings/dumpsys where available.
- Optional animation scale change attempts to set Android global animation scales to 0.5x through Shizuku. Android/vendor restrictions may block it.
- Restore is best-effort; if backup values cannot be read, restore animation scales manually in Developer options.
- No modification of Free Fire files/process, no auto-aim, no recoil control.

BUILD FROM PHONE WITH GITHUB ACTIONS
1. Create/open a GitHub repository, e.g. friss-aim-tools.
2. Upload this ZIP at the repository root with exact name FRISS-AIM-TOOLS-Project.zip.
3. Upload .github/workflows/build.yml from this ZIP to the same path in the repo.
4. Open Actions > Build FRISS AIM TOOLS APK > Run workflow.
5. When complete, open Artifacts > FRISS-AIM-TOOLS-debug-apk and download it.
6. Extract the artifact ZIP and install app-debug.apk.
7. Start Shizuku service, open FRISS AIM TOOLS, tap Connect / Request permission, then grant permission in Shizuku.

This is source code, not a compiled APK. The build has not been tested in your GitHub account/device. If compilation fails, send the first red error log. Never share Shizuku pairing codes or GitHub tokens.
