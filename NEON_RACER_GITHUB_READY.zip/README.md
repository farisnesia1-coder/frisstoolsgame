# NEON RACER — FRISS EDITION (GitHub-ready)

Android arcade racing starter project using a Java Android frontend and C++17 gameplay logic through JNI.

## Added in this version
- Main menu and Start Race button
- How To Play dialog
- Neon-styled player car and traffic cars drawn in native C++ Canvas calls
- Nitro flame effect
- Score, collectible coins, crash/game-over state
- Best score saved locally with Android SharedPreferences
- GitHub Actions workflow to build a debug APK on push or manually

## Requirements for local build
- Android Studio
- JDK 17
- Android SDK Platform 35
- Android NDK
- CMake 3.22.1

## Build with GitHub Actions (no need to compile on phone)
1. Create a new GitHub repository, e.g. `neon-racer`.
2. Upload the contents of this folder to the repository root (not the containing folder itself).
3. Commit and push to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Choose **Build NEON RACER APK** and click **Run workflow**, or wait for the push build.
6. Open the completed workflow run and download the `neon-racer-debug-apk` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android device.

## Controls
- Tap left side of road: steer left.
- Tap right side: steer right.
- Tap center area: nitro.
- Tap near the top: pause/resume.
- Best score persists between sessions.

## Important
This is a starter prototype. The GitHub Actions build has not been executed from this chat, so verify the first workflow run. The project uses Android's Canvas drawing for stylized cars instead of imported sprite image files; it can be upgraded later with custom PNG sprites, sound, garage, and more levels.
