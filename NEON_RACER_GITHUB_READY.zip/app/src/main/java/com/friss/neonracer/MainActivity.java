package com.friss.neonracer;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    static { System.loadLibrary("neonracer"); }

    private FrameLayout root;
    private GameView game;
    private SharedPreferences prefs;
    private TextView hud;
    private boolean inGame = false;
    private int lastScore = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("neon_racer_save", MODE_PRIVATE);
        immersive();
        root = new FrameLayout(this);
        game = new GameView();
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));
        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(15);
        hud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hud.setPadding(20, 16, 20, 12);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(hud, hp);
        setContentView(root);
        showMenu();
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        return t;
    }

    private Button button(String value, Runnable action) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 145, 205)));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void showMenu() {
        inGame = false;
        nativeReset();
        root.removeView(hud);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setGravity(Gravity.CENTER);
        menu.setPadding(28, 24, 28, 24);
        menu.setBackgroundColor(Color.rgb(5, 10, 24));

        TextView title = text("NEON RACER", 34, Color.rgb(40, 220, 255));
        TextView subtitle = text("FRISS EDITION", 15, Color.WHITE);
        TextView description = text("DODGE • BOOST • SURVIVE", 12, Color.rgb(150, 190, 220));
        int best = prefs.getInt("best_score", 0);
        TextView bestView = text("BEST SCORE  " + best, 17, Color.rgb(255, 210, 70));

        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-1, -2);
        gap.setMargins(0, 8, 0, 8);
        menu.addView(title, gap);
        menu.addView(subtitle, gap);
        menu.addView(description, gap);
        menu.addView(bestView, gap);
        menu.addView(button("▶  START RACE", () -> startGame()), gap);
        menu.addView(button("HOW TO PLAY", () -> showHelp()), gap);
        TextView footer = text("OFFLINE ARCADE • BUILT WITH C++", 10, Color.GRAY);
        menu.addView(footer, gap);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(menu, mp);
        root.setTag(menu);
        hud.setVisibility(View.GONE);
    }

    private void showHelp() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("HOW TO PLAY")
            .setMessage("Tap the LEFT side of the road to steer left. Tap the RIGHT side to steer right. Tap the CENTER for nitro. Avoid red cars and collect gold coins. Tap near the top to pause/resume.")
            .setPositiveButton("GOT IT", (d, w) -> {})
            .show();
    }

    private void startGame() {
        Object tag = root.getTag();
        if (tag instanceof View) root.removeView((View) tag);
        root.setTag(null);
        inGame = true;
        nativeReset();
        hud.setVisibility(View.VISIBLE);
        lastScore = 0;
        game.invalidate();
    }

    private void finishGameIfNeeded() {
        if (!inGame || !nativeGameOver()) return;
        int score = nativeScore();
        int best = prefs.getInt("best_score", 0);
        if (score > best) {
            prefs.edit().putInt("best_score", score).apply();
        }
        inGame = false;
        new android.app.AlertDialog.Builder(this)
            .setTitle("RACE OVER")
            .setMessage("Score: " + score + "\\nBest: " + Math.max(score, best) + "\\nCoins: " + nativeCoins())
            .setCancelable(false)
            .setPositiveButton("RACE AGAIN", (d, w) -> startGame())
            .setNegativeButton("MAIN MENU", (d, w) -> showMenu())
            .show();
    }

    @Override protected void onPause() {
        super.onPause();
        if (game != null) nativePause(true);
    }
    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (game != null && inGame) nativePause(false);
    }

    private class GameView extends View {
        GameView() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            nativeRender(canvas, getWidth(), getHeight());
            if (inGame) {
                int score = nativeScore();
                hud.setText("NEON RACER   •   SCORE " + score + "   •   COINS " + nativeCoins());
                finishGameIfNeeded();
                postInvalidateDelayed(16);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (!inGame) return true;
            if (e.getAction() == MotionEvent.ACTION_DOWN || e.getAction() == MotionEvent.ACTION_MOVE) {
                nativeTouch(e.getX() / Math.max(1f, getWidth()), e.getY() / Math.max(1f, getHeight()));
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                nativeTouch(-1f, -1f);
                return true;
            }
            return true;
        }
    }

    private native void nativeRender(android.graphics.Canvas canvas, int width, int height);
    private native void nativeTouch(float x, float y);
    private native int nativeScore();
    private native int nativeCoins();
    private native boolean nativeGameOver();
    private native void nativePause(boolean paused);
    private native void nativeReset();
}
