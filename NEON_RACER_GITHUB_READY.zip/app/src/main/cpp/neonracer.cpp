#include <jni.h>
#include <algorithm>
#include <cmath>
#include <random>
#include <vector>

struct Obstacle { float x, y, w, h; bool coin; bool active; };
static float carX = 0.5f, roadScroll = 0.f;
static float speed = 0.0048f;
static int score = 0, coins = 0, frameCount = 0;
static bool paused = false, gameOver = false, nitro = false;
static std::vector<Obstacle> objects;
static std::mt19937 rng(7);

static jint rgb(int r,int g,int b) {
    return (jint)(0xff000000u | (r<<16) | (g<<8) | b);
}
static void setColor(JNIEnv* e, jobject p, jmethodID m, int c) { e->CallVoidMethod(p,m,(jint)c); }
static void rect(JNIEnv* e,jobject c,jmethodID draw,jobject p,jmethodID color,
                 float l,float t,float r,float b,int col) {
    setColor(e,p,color,col); e->CallVoidMethod(c,draw,l,t,r,b,p);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRender(JNIEnv* env, jobject, jobject canvas, jint width, jint height) {
    jclass cc=env->GetObjectClass(canvas);
    jclass pc=env->FindClass("android/graphics/Paint");
    jmethodID ctor=env->GetMethodID(pc,"<init>","()V");
    jobject paint=env->NewObject(pc,ctor);
    jmethodID color=env->GetMethodID(pc,"setColor","(I)V");
    jmethodID draw=env->GetMethodID(cc,"drawRect","(FFFFLandroid/graphics/Paint;)V");
    jmethodID textSize=env->GetMethodID(pc,"setTextSize","(F)V");
    jmethodID drawText=env->GetMethodID(cc,"drawText","(Ljava/lang/String;FFLandroid/graphics/Paint;)V");

    float w=std::max(1,(int)width), h=std::max(1,(int)height);
    rect(env,canvas,draw,paint,color,0,0,w,h,rgb(5,9,22));
    float roadL=w*.15f, roadR=w*.85f;
    rect(env,canvas,draw,paint,color,roadL,0,roadR,h,rgb(22,29,48));
    rect(env,canvas,draw,paint,color,roadL-4,0,roadL,h,rgb(0,205,255));
    rect(env,canvas,draw,paint,color,roadR,0,roadR+4,h,rgb(0,205,255));

    if (!paused && !gameOver) {
        roadScroll += nitro ? .035f : .018f;
        if (roadScroll>1) roadScroll-=1;
        frameCount++;
        if (frameCount%5==0) score += nitro ? 2 : 1;
        if (frameCount%72==0) {
            std::uniform_real_distribution<float> lane(.25f,.75f);
            bool coin=(frameCount%144==0);
            objects.push_back({lane(rng),-.10f,coin?.045f:.09f,coin?.045f:.105f,coin,true});
            if(objects.size()>35) objects.erase(objects.begin());
        }
    }
    for(int lane=1;lane<=2;lane++) {
        float x=w*(.15f+.70f*lane/3.f);
        for(int i=0;i<8;i++) {
            float yy=std::fmod(i/8.f+roadScroll,1.f)*h;
            rect(env,canvas,draw,paint,color,x-2,yy,x+2,yy+h*.065f,rgb(85,105,135));
        }
    }

    for(auto &o:objects) {
        if(!paused&&!gameOver&&o.active) o.y += speed*(nitro?1.75f:1.f);
        float ox=o.x*w, oy=o.y*h;
        if(o.coin) {
            rect(env,canvas,draw,paint,color,ox-w*.018f,oy-h*.018f,ox+w*.018f,oy+h*.018f,rgb(255,205,55));
            if(std::abs(o.x-carX)<.07f&&std::abs(o.y-.79f)<.075f&&o.active){coins++;score+=25;o.active=false;}
        } else {
            // Traffic car body, windshield, bumper and rear lights
            rect(env,canvas,draw,paint,color,ox-o.w*w/2,oy,ox+o.w*w/2,oy+o.h*h,rgb(250,55,92));
            rect(env,canvas,draw,paint,color,ox-o.w*w*.31f,oy+o.h*h*.18f,ox+o.w*w*.31f,oy+o.h*h*.42f,rgb(30,45,72));
            rect(env,canvas,draw,paint,color,ox-o.w*w*.38f,oy+o.h*h*.78f,ox-o.w*w*.20f,oy+o.h*h*.92f,rgb(255,230,180));
            rect(env,canvas,draw,paint,color,ox+o.w*w*.20f,oy+o.h*h*.78f,ox+o.w*w*.38f,oy+o.h*h*.92f,rgb(255,230,180));
            if(std::abs(o.x-carX)<.078f&&o.y+o.h>.75f&&o.y<.89f&&o.active) gameOver=true;
        }
        if(o.y>1.1f)o.active=false;
    }

    float cx=carX*w, cy=h*.81f;
    // Nitro flame behind player car
    if(nitro&&!gameOver) {
        rect(env,canvas,draw,paint,color,cx-w*.025f,cy+h*.045f,cx+w*.025f,cy+h*.12f,rgb(0,210,255));
        rect(env,canvas,draw,paint,color,cx-w*.013f,cy+h*.045f,cx+w*.013f,cy+h*.09f,rgb(255,245,130));
    }
    // Player car body with layered highlights
    rect(env,canvas,draw,paint,color,cx-w*.045f,cy-h*.04f,cx+w*.045f,cy+h*.055f,rgb(0,205,255));
    rect(env,canvas,draw,paint,color,cx-w*.031f,cy-h*.025f,cx+w*.031f,cy+h*.028f,rgb(20,45,76));
    rect(env,canvas,draw,paint,color,cx-w*.023f,cy-h*.019f,cx+w*.023f,cy+h*.002f,rgb(120,230,255));
    rect(env,canvas,draw,paint,color,cx-w*.040f,cy+h*.030f,cx-w*.024f,cy+h*.049f,rgb(255,255,255));
    rect(env,canvas,draw,paint,color,cx+w*.024f,cy+h*.030f,cx+w*.040f,cy+h*.049f,rgb(255,255,255));
    rect(env,canvas,draw,paint,color,cx-w*.052f,cy-h*.005f,cx-w*.043f,cy+h*.030f,rgb(4,8,18));
    rect(env,canvas,draw,paint,color,cx+w*.043f,cy-h*.005f,cx+w*.052f,cy+h*.030f,rgb(4,8,18));

    env->CallVoidMethod(paint,textSize,h*.03f);
    if(gameOver) {
        setColor(env,paint,color,rgb(255,75,100));
        jstring s=env->NewStringUTF("CRASHED!");
        env->CallVoidMethod(canvas,drawText,s,w*.39f,h*.48f,paint);
        env->DeleteLocalRef(s);
    } else if(paused) {
        setColor(env,paint,color,rgb(255,255,255));
        jstring s=env->NewStringUTF("PAUSED");
        env->CallVoidMethod(canvas,drawText,s,w*.42f,h*.48f,paint);
        env->DeleteLocalRef(s);
    }
    env->DeleteLocalRef(paint); env->DeleteLocalRef(cc); env->DeleteLocalRef(pc);
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeTouch(JNIEnv*,jobject,jfloat x,jfloat y) {
    if(x<0){nitro=false;return;}
    if(gameOver){gameOver=false;score=0;frameCount=0;objects.clear();carX=.5f;return;}
    if(y<.16f){paused=!paused;return;}
    if(y>.40f&&y<.96f){
        if(x<.43f)carX=std::max(.23f,carX-.12f);
        else if(x>.57f)carX=std::min(.77f,carX+.12f);
        else nitro=true;
    }
}
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeScore(JNIEnv*,jobject){return score;}
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeCoins(JNIEnv*,jobject){return coins;}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_friss_neonracer_MainActivity_nativeGameOver(JNIEnv*,jobject){return gameOver?JNI_TRUE:JNI_FALSE;}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativePause(JNIEnv*,jobject,jboolean p){paused=(p==JNI_TRUE);}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeReset(JNIEnv*,jobject){
    carX=.5f;roadScroll=0;score=0;coins=0;frameCount=0;paused=false;gameOver=false;nitro=false;objects.clear();
}
